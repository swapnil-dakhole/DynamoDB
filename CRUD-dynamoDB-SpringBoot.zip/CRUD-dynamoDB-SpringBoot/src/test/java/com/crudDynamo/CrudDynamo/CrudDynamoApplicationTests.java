package com.crudDynamo.CrudDynamo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudDynamoApplicationTests {

	@Test
	void contextLoads() {
	}

}
