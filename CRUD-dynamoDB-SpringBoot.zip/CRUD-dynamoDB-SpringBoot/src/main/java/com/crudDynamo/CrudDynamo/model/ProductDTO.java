package com.crudDynamo.CrudDynamo.model;



public class ProductDTO {
    private String id;
    private String name;
    private double price;
    private Integer stockCount;

    // Default Constructor
    public ProductDTO() {}

    // Parameterized Constructor
    public ProductDTO(String id, String name, double price, Integer stockCount) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stockCount = stockCount;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public Integer getStockCount() {
        return stockCount;
    }

    // Setters
    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStockCount(Integer stockCount) {
        this.stockCount = stockCount;
    }

    @Override
    public String toString() {
        return "ProductDTO{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", stockCount=" + stockCount +
                '}';
    }
}




