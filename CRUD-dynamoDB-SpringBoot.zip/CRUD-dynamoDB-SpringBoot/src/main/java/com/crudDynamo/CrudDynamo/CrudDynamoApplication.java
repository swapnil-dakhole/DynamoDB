package com.crudDynamo.CrudDynamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudDynamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudDynamoApplication.class, args);
	}

}
